% /***************************************************************************
%  *   Copyright (C) 2006 by Leonid Livshitz and Yoram Rudy  *
%  *   Email rudy@wustl.edu   *
%  *                                                                         *
%  *   This program is free software; you can redistribute it and/or modify  *
%  *   it under the terms of the GNU General Public License as published by  *
%  *   the Free Software Foundation; either version 2 of the License, or     *
%  *   (at your option) any later version.                                   *
%  *                                                                         *
%  *   This program is distributed in the hope that it will be useful,       *
%  *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
%  *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
%  *   GNU General Public License for more details.                          *
%  *                                                                         *
%  *   You should have received a copy of the GNU General Public License     *
%  *   along with this program; if not, write to the                         *
%  *   Free Software Foundation, Inc.,                                       *
%  *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
%  ***************************************************************************/






function [currents,State,Ti]=mainLRd_web2007(data) %% comment to run stand alone
constantsLRd
%% YOU CAN RUN mainLRd_web2007 stand alone
% you need to provide value for parameters supplied by GUI
% i.e. extracellular concentrations, number of beats and cycling length
% and to comment the first line
% data.bcl=0.400;% data.freq=1; % number of beats % data.k_o=4.5; % data.na_o=140;% data.ca_o=1.8;%data.LastBCL=0.400; Steady state initial 
data.sqrt=(data.k_o/5.4).^(1/2);
 load Initial_conditions2007  %% load table of prepaced initial conditions(at selected cycling length for almost steady-state) at 
                               %% see values of the first column of matrix X0
 [i,j]=min(abs(X0(:,1)-data.LastBCL)); %% find closest available
    x0=X0(j,2:end);
State=[];Ti=[];Stm=[];
opts = odeset('RelTol',1e-6);
h4 = waitbar(0,' Matlab is working hard, Please wait ...');
State=[];Ti=[];Stm=[]; %% state matrix initiation
for p=1:data.freq
    [t,X]=ode15s('cell_web2007',[0  data.bcl],x0,opts,data);
    %[t,X]=ode15s('cell_alg',[0  data.bcl],x0,opts,data);
    
        Ti=[Ti; t+(data.bcl*(p-1))];
    State=[State; X];
    St=data.Is*ones(1,length(t));
    St((find(t>data.fnsh)))=0;
    Stm=[Stm  St];
     waitbar(p/data.freq,h4)
    x0=[X(end,1:end)];
end
[currents]=print_LRd_web2007(State,Ti,Stm,data);
close(h4)

