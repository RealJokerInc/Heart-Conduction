function varargout = LRd2007(varargin)
% LRD2007 M-file for LRd2007.fig
%      LRD2007, by itself, creates a new LRD2007 or raises the existing
%      singleton*.
%
%      H = LRD2007 returns the handle to a new LRD2007 or the handle to
%      the existing singleton*.
%
%      LRD2007('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LRD2007.M with the given input arguments.
%
%      LRD2007('Property','Value',...) creates a new LRD2007 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before LRd2007_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to LRd2007_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help LRd2007

% Last Modified by GUIDE v2.5 14-Nov-2007 05:33:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @LRd2007_OpeningFcn, ...
    'gui_OutputFcn',  @LRd2007_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before LRd2007 is made visible.
function LRd2007_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to LRd2007 (see VARARGIN)

% Choose default command line output for LRd2007
handles.output = hObject;


% INITIAL DATA
bcl=0.400;
freq=1;
k_o=4.5;
na_o=140;
ca_o=1.8;
G_gap=0;
LastBCL=0.400;
set(handles.editLastBCL,'String',num2str(LastBCL));
handles.LastBCL =LastBCL;
% % bcl=get(handles.sliderBCL, 'value');;
set(handles.editBCL,'String',num2str(bcl));
set(handles.sliderBCL,'Value', bcl);
%freq = get(handles.sliderFreq,'value');
set(handles.editFreq,'String',num2str(round(freq)));
set(handles.sliderFreq,'Value',freq);
%k_o  =  get(handles.sliderKo,'value') ;
 set(handles.sliderKo,'Value',k_o) ;
set(handles.editKo,'String',num2str(k_o));


%na_o  =  get(handles.sliderSodium,'value') ;
set(handles.sliderSodium,'Value',na_o)
set(handles.editSodium,'String',num2str(na_o));


 set(handles.sliderCalcium,'Value',ca_o)
 set(handles.editCalcium,'String',num2str(ca_o));
handles.freq=freq;
handles.bcl=bcl;
handles.k_o=k_o;
handles.ca_o=ca_o;
handles.v=0;
handles.na_o=na_o;
handles.G_gap=G_gap;
handles.LastBCL=LastBCL;
%  splash('logo2.jpg','jpeg')
% Update handles structure

% set(hObject, 'Units', 'pixels');
% handles.banner = imread(['Slide2.jpg']); % Read the image file banner.jpg
% info = imfinfo(['Slide2.jpg']); % Determine the size of the image file
% position = get(hObject, 'Position');
% set(hObject, 'Position', [position(1:2) info.Width + 100 info.Height + 100]);
% axes(handles.axes1);
% image(handles.banner)
% set(handles.axes1, ...
% 'Visible', 'off', ...
% 'Units', 'pixels', ...
% 'Position', [50 50 info.Width info.Height]);
axes(handles.axes1); a= (imread('logoCBAClong.jpg'));
 image(a);
set(handles.axes1,'Visible', 'off')

 guidata(hObject, handles);
  axes(handles.axes2)
  text(0.1 ,0.5,'Choose parameters and \newline press Start to proceed','FontSize',20,'FontWeight','bold')
set(handles.axes2,'Visible', 'off')
  % UIWAIT makes LRd2007 wait for user response (see UIRESUME)
% uiwait(handles.figure1);

set(handles.axes3,'Visible', 'off')
% --- Outputs from this function are returned to the command line.
function varargout = LRd2007_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function sliderBCL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function sliderBCL_Callback(hObject, eventdata, handles)
% hObject    handle to sliderBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


bcl=get(handles.sliderBCL, 'value');;
set(handles.editBCL,'String',num2str(round(bcl)));


handles.bcl=bcl;


% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function sliderFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function sliderFreq_Callback(hObject, eventdata, handles)
% hObject    handle to sliderFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
freq = get(handles.sliderFreq,'value');
set(handles.editFreq,'String',num2str(round(freq)));

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
handles.freq=freq;
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function sliderKo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderKo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function sliderKo_Callback(hObject, eventdata, handles)
% hObject    handle to sliderKo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
k_o  =  get(handles.sliderKo,'value') ;

set(handles.editKo,'String',num2str(k_o));
handles.k_o=k_o;

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%The callback for the Ki Current value follows a similar approach.
data.freq=round(handles.freq);
data.bcl=1000*handles.bcl;
data.k_o=handles.k_o;
data.ca_o=handles.ca_o;
data.na_o=handles.na_o;
data.G_gap=handles.G_gap/20;
data.LastBCL=1000*handles.LastBCL ;
[currents,State,t]=mainLRd_web2007(data);

d=Import(State,currents,t,handles);




%guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function editBCL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editBCL_Callback(hObject, eventdata, handles)
% hObject    handle to editBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editBCL as text
%        str2double(get(hObject,'String')) returns contents of editBCL as a double
bcl = str2double(get(handles.editBCL,'String'));

if bcl >= get(handles.sliderBCL,'Min') & ...
        bcl <= get(handles.sliderBCL,'Max')
    set(handles.sliderBCL,'Value',bcl);
elseif  bcl > get(handles.sliderBCL,'Max')
    set(handles.sliderBCL,'Value',get(handles.sliderBCL,'Max'));
      set(handles.editBCL,'String',num2str(get(handles.sliderBCL,'Max'))) 
elseif  bcl < get(handles.sliderBCL,'Min')
    
      set(handles.sliderBCL,'Value',get(handles.sliderBCL,'Min'));
      set(handles.editBCL,'String',num2str(get(handles.sliderBCL,'Min')))
else
      set(handles.sliderBCL,'Value',get(handles.sliderBCL,'Min'));
      set(handles.editBCL,'String',num2str(get(handles.sliderBCL,'Min')))
end

handles.bcl=bcl;
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function editFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editFreq_Callback(hObject, eventdata, handles)
% hObject    handle to editFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFreq as text
%        str2double(get(hObject,'String')) returns contents of editFreq as a double
freq = str2double(get(handles.editFreq,'String'));

if freq >= get(handles.sliderFreq,'Min') & ...
        freq <= get(handles.sliderFreq,'Max')
    set(handles.sliderFreq,'Value',freq);
elseif freq >get(handles.sliderFreq,'Max')
    set(handles.sliderFreq,'Value',get(handles.sliderFreq,'Max'));
         set(handles.editFreq,'String',num2str(get(handles.sliderFreq,'Max'))) 
elseif freq < get(handles.sliderFreq,'Min')
    
      set(handles.sliderFreq,'Value',get(handles.sliderFreq,'Min'));
      set(handles.editFreq,'String',num2str(get(handles.sliderFreq,'Min')))
      
else
     set(handles.sliderFreq,'Value',get(handles.sliderFreq,'Min'));
      set(handles.editFreq,'String',num2str(get(handles.sliderFreq,'Min')))
      
end

handles.freq=freq;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editKo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editKo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editKo_Callback(hObject, eventdata, handles)
% hObject    handle to editKo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editKo as text
%        str2double(get(hObject,'String')) returns contents of editKo as a double

k_o = str2double(get(handles.editKo,'String'));

if k_o >= get(handles.sliderKo,'Min') & ...
        k_o <= get(handles.sliderKo,'Max')
    set(handles.sliderKo,'Value',k_o);
elseif k_o > get(handles.sliderKo,'Max')
         set(handles.sliderKo,'Value',get(handles.sliderKo,'Max'));
         set(handles.editKo,'String',num2str(get(handles.sliderKo,'Max'))) 
elseif k_o < get(handles.sliderKo,'Min')
    
      set(handles.sliderKo,'Value',get(handles.sliderKo,'Min'));
      set(handles.editKo,'String',num2str(get(handles.sliderKo,'Min')))
else
      set(handles.sliderKo,'Value',get(handles.sliderKo,'Min'));
      set(handles.editKo,'String',num2str(get(handles.sliderKo,'Min')))
end

handles.k_o=k_o;
guidata(hObject, handles);
% --- Executes on slider movement.
function sliderSodium_Callback(hObject, eventdata, handles)
% hObject    handle to sliderSodium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

na_o=get(handles.sliderSodium, 'value');;
set(handles.editSodium,'String',num2str(na_o));


handles.na_o=na_o;


% Update handles structure
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function sliderSodium_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderSodium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSodium_Callback(hObject, eventdata, handles)
% hObject    handle to editSodium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSodium as text
%        str2double(get(hObject,'String')) returns contents of editSodium as a double

na_o = str2double(get(handles.editSodium,'String'));

if  na_o >= get(handles.sliderSodium,'Min') & ...
        na_o <= get(handles.sliderSodium,'Max')
    set(handles.sliderSodium,'Value', na_o);
elseif na_o >get(handles.sliderSodium,'Max')
    set(handles.sliderSodium,'Value',get(handles.sliderSodium,'Max'));
         set(handles.editSodium,'String',num2str(get(handles.sliderSodium,'Max'))) 
elseif na_o < get(handles.sliderFreq,'Min')
    
      set(handles.sliderSodium,'Value',get(handles.sliderSodium,'Min'));
      set(handles.editSodium,'String',num2str(get(handles.sliderSodium,'Min')))
      
else
    
      set(handles.sliderSodium,'Value',get(handles.sliderSodium,'Min'));
      set(handles.editSodium,'String',num2str(get(handles.sliderSodium,'Min')))
end

handles.na_o =na_o ;
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function editSodium_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSodium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

val = get(hObject,'Value');
str = get(hObject,'String');

if handles.v==1
    axes(handles.axes2)
else
    axes(handles.axes3)
end

switch str{val};

    case 'Calcium (myoplasmic)' % User selects

        [h2]=plot(handles.t,1000*handles.Ca);grid on
        set(h2,'LineWidth',2')  ;ylabel(' Ca^{2+} (\mu M) ','FontSize',10,'FontWeight','bold') ;set(gca,'FontSize',10,'FontWeight','bold');
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
        zoom on
        
          case 'Calcium total (myoplasmic)' 
        
         [h1]=plot(handles.t,handles.cmdn+handles.trpn,handles.t,handles.Ca+handles.cmdn+handles.trpn);grid on


 legend('buffered Ca^{2+}','total Ca^{2+}',0)
   set(h1,'LineWidth',2')  ;
ylabel(' Ca^{2+} [mM] ','FontSize',10,'FontWeight','bold') ;
set(gca,'FontSize',10,'FontWeight','bold');
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
 zoom on
       
        
        
    case 'Potassium (myoplasmic)' % User selects

        h2=plot(handles.t,handles.Kai);   set(h2,'LineWidth',2')
        grid on;zoom on;  ylabel(' K^{+} (mM)','FontSize',10,'FontWeight','bold');
        set(gca,'FontSize',10,'FontWeight','bold')
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
    case 'TMP' % User selects
        h2=plot(handles.t,handles.V,handles.t,handles.V2); ; ylabel(' TMP (mV)','FontSize',10,'FontWeight','bold'); set(gca,'FontSize',10,'FontWeight','bold');set(h2,'LineWidth',2');grid on;zoom on;
    case 'Sodium (myoplasmic)' % User selects
       h2=plot(handles.t,handles.Nai);
        grid on;zoom on;   set(h2,'LineWidth',2'); ylabel(' Na^{+} (mM)','FontSize',10,'FontWeight','bold'); set(gca,'FontSize',10,'FontWeight','bold');
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold');

    case 'INa channel gates' %
        h2=plot(handles.t,handles.M,'r',handles.t,handles.J,handles.t,handles.H);
        
        legend('m','j','h',0);  grid on;set(h2,'LineWidth',2');
        ylabel(' m, j, h gates ','FontSize',10,'FontWeight','bold');zoom on ; 
        set(gca,'FontSize',10,'FontWeight','bold')
        axis tight
    case 'h- Na inactivation gate'%
        h2=plot(handles.t,handles.H); ; set(h2,'LineWidth',2');ylabel(' H gate ','FontSize',10,'FontWeight','bold');
         set(gca,'FontSize',10,'FontWeight','bold');grid on  ;zoom on ;
 
    case 'IKr channel gates'
        h2=plot(handles.t,handles.Xr); ylabel(' xr gate ','FontSize',10,'FontWeight','bold');grid on;zoom on ;
        set(h2,'LineWidth',2')
        set(gca,'FontSize',10,'FontWeight','bold')
       case 'IKs channel gates'
        h2=plot(handles.t,handles.XS,handles.t,handles.XS2);
        ylabel(' Iks gates ','FontSize',10,'FontWeight','bold');
        grid on;zoom on ; set(h2,'LineWidth',2') ;
       
    legend('xs1-fast','xs2-slow',0)
        set(gca,'FontSize',10,'FontWeight','bold')
    
    case 'ICal channel gates' %
        h2=plot(handles.t,handles.d); ylabel(' d ','FontSize',10,'FontWeight','bold');grid on;zoom on ; set(h2,'LineWidth',2')
       xlabel('Time (sec)','FontSize',10,'FontWeight','bold')

    case 'ICaL channel gates' %
        h2=plot(handles.t,handles.d,'r',handles.t,handles.f,handles.t,handles.fca);grid on;zoom on ; set(h2,'LineWidth',2')
        ylabel(' I_{Ca(L)} gates ','FontSize',10,'FontWeight','bold')
        legend('d-activation','f-inactivation','fca- inactivation Ca^{2+}',0)
        set(gca,'FontSize',10,'FontWeight','bold')
   xlabel('Time (sec)','FontSize',10,'FontWeight','bold')

    case 'JSR' %
        h2=plot(handles.t,handles.JSR);grid on;zoom on
        ylabel(' Ca^{2+}_{jSR} ','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2') ; set(h2,'LineWidth',2')
    case 'Ca in SR' %
         h2=plot(handles.t,handles.NSR,handles.t,handles.JSR,handles.t,handles.JSR+handles.csqn);grid on;zoom on
        ylabel(' [Ca^{2+}] in SR (mM) ','FontSize',10,'FontWeight','bold') ;
         legend('[Ca^{2+}] in nSR','free [Ca^{2+}] in jSR','Total [Ca^{2+}] in jSR',0);
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
         
end
guidata(hObject,handles)
% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
val = get(hObject,'Value');
str = get(hObject,'String');
if handles.v==1
    axes(handles.axes2)
else
    axes(handles.axes3)
end
zoom on
switch str{val};
    case 'INa (Fast Na current)'
%     
        h2=plot(handles.t,handles.INa);
        grid on  ; set(h2,'LineWidth',2');zoom on;
        ylabel(' I_{Na} (\mu A/ \mu F)','FontSize',10,'FontWeight','bold'); set(gca,'FontSize',10,'FontWeight','bold') ;xlabel('Time (sec)','FontSize',10,'FontWeight','bold');
  
       case 'INa normalized conductance' %
        h2=plot(handles.t,(handles.J).*(handles.H).*(handles.M).^3);
        ylabel(' G_{Na} (mS/\mu F)','FontSize',10,'FontWeight','bold');
        grid on;zoom on ; set(h2,'LineWidth',2');grid on;zoom on ;
    set(gca,'FontSize',10,'FontWeight','bold')
    case 'IKs (Slow delayed rectifier K current)'
        h2=plot(handles.t,handles.iks);grid on
        set(h2,'LineWidth',2');  ylabel(' I_{Ks}  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold')
        set(gca,'FontSize',10,'FontWeight','bold'); xlabel('Time (sec)','FontSize',10,'FontWeight','bold');zoom on;
    
    case 'IKs normalized conductance'
        h2=plot(handles.t,handles.G_Ks);grid on;zoom on
        ylabel(' G_{Ks}(mS/\mu F) ','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2')
    set(gca,'FontSize',10,'FontWeight','bold')
    case 'IKr (Fast delayed rectifier K current)'
        h2=plot(handles.t,handles.ikr);grid on
        set(h2,'LineWidth',2'),  ylabel(' I_{Kr} (\mu A/ \mu F) ','FontSize',10,'FontWeight','bold'),
        set(gca,'FontSize',10,'FontWeight','bold')
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold');zoom on; grid on  ;
    
     case 'IKr normalized conductance'
        h2=plot(handles.t,handles.G_Kr);grid on;zoom on
        ylabel(' G_{Kr}(mS/\mu F)','FontSize',10,'FontWeight','bold') ;
        set(h2,'LineWidth',2')
        set(gca,'FontSize',10,'FontWeight','bold')
    
    case 'ICal (Ca current through L-type channel)'
        h2=plot(handles.t,handles.ical);grid on
        set(h2,'LineWidth',2'),  ylabel(' I_{Ca}  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold'), set(gca,'FontSize',10,'FontWeight','bold')
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold');zoom on;set(gca,'FontSize',10,'FontWeight','bold')
     case 'ICaL normalized conductance'
        h2=plot(handles.t,(handles.f).*(handles.d).*(handles.fca));grid on
        set(h2,'LineWidth',2'),  ylabel('G_{ICa(L),Ca} (mS/ \mu F) ','FontSize',10,'FontWeight','bold'), set(gca,'FontSize',10,'FontWeight','bold')
        xlabel('Time (sec)','FontSize',10,'FontWeight','bold');zoom on;set(gca,'FontSize',10,'FontWeight','bold')
  
    
    
    case 'ICalNa'
        h2=plot(handles.t,handles.icalna);ylabel(' IlCaNa  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2');grid on;zoom on
    case 'ICalK'
        h2=plot(handles.t,handles.icalk);ylabel(' IlCaK  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2');grid on;zoom on
    case 'Irel (Ca release from JSR)'
        h2=plot(handles.t,handles.ir);ylabel(' I_{rel} (mM/msec)','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2'),grid on;zoom on
 set(gca,'FontSize',10,'FontWeight','bold');
    case 'Irel conductance'
        h2=plot(handles.t,handles.Grel);ylabel(' G_{rel} (mM/sec)','FontSize',10,'FontWeight','bold') ; set(h2,'LineWidth',2'),grid on;zoom on
 set(gca,'FontSize',10,'FontWeight','bold');
    case 'ICat'
        h2=plot(handles.t,handles.icat);grid on;zoom on;
        set(h2,'LineWidth',2') ; ylabel(' Ca tran  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold')
        set(gca,'FontSize',10,'FontWeight','bold'); xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
    case 'INaCa (Na/Ca  exchanger)'
        h2=plot(handles.t,handles.inaca);grid on;;zoom on
        set(h2,'LineWidth',2') ;
        ylabel(' INaCa  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');
           set(gca,'FontSize',10,'FontWeight','bold')
    case 'INaK (Na/K pump)'
        h2=plot(handles.t,handles.inak);  grid on;zoom on;
        set(h2,'LineWidth',2') ;
        ylabel(' Inak  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');
   set(gca,'FontSize',10,'FontWeight','bold')
    case 'ICab, IpCa'
        h2=plot(handles.t,handles.icab,handles.t,handles.ipca);  grid on;zoom on;legend('I_{Cab}','I_{pCa}',0)
        set(h2,'LineWidth',2') ; ylabel(' ICab  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');  set(gca,'FontSize',10,'FontWeight','bold')
    case 'Iup'
        h2=plot(handles.t,handles.iup,handles.t,handles.ileak);  grid on;zoom on;
        legend('I_{up}','I_{leak}',0)
         %title(['$\int Ca^{2+}dt=$', num2str(sum(-handles.iup+handles.ir+handles.ileak))], 'fontsize',12,'interpreter','latex');
        set(h2,'LineWidth',2') ; ylabel('  (mM)','FontSize',10,'FontWeight','bold');  set(gca,'FontSize',10,'FontWeight','bold')
    case 'INab'
        h2=plot(handles.t,handles.inab);  grid on;zoom on;
        set(h2,'LineWidth',2') ; ylabel('INab  (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');
    case 'Stimulus current'
        h2=plot(handles.t,handles.stm);  grid on;zoom on;
        set(h2,'LineWidth',2') ; ylabel('Stimuli (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');
         set(gca,'FontSize',10,'FontWeight','bold');
    case 'IK1 (Time independent K current)' 
        h2=plot(handles.t,handles.IK1,handles.t,handles.IK1+handles.IKp);  grid on;zoom on;
        set(h2,'LineWidth',2') ; ylabel('IK1 (\mu A/ \mu F)','FontSize',10,'FontWeight','bold'); set(gca,'FontSize',10,'FontWeight','bold')
  
    case 'IKp (Plateau K current)'
        h2=plot(handles.t,handles.IKp);  grid on;zoom on;
    
        set(h2,'LineWidth',2') ; ylabel('IKp (\mu A/ \mu F)','FontSize',10,'FontWeight','bold');
 
    set(gca,'FontSize',10,'FontWeight','bold')
   
    case 'IK1 normalized conductance'
        h2=plot(handles.t,handles.G_K1);  grid on;zoom on;
        set(h2,'LineWidth',2') ; ylabel('G_{K1} (mS/\mu F)','FontSize',10,'FontWeight','bold');
      set(gca,'FontSize',10,'FontWeight','bold')
   case 'Total Ca'
        %
        h2=plot(handles.t,handles.caiont);grid on;zoom on
        ylabel('$\sum Ca^{2+}dt \mu A/\mu F$','FontSize',10,'FontWeight','bold','interpreter','latex') ;
        %          legend('\int [Ca^{2+}]dt=', num2str(Int_caiont),0);
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
       % title(['$\int \sum Ca^{2+}dt=$', num2str(handles.Int_caiont)], 'fontsize',12,'interpreter','latex');
    case 'Total Na' %
        h2=plot(handles.t,handles.naiont);grid on;zoom on
        ylabel('$\sum Na^{+}~ [\mu A/\mu F]$','FontSize',12,'FontWeight','bold','interpreter','latex') ;
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
       % title(['$\int Na^{+}dt=$', num2str(handles.Int_naiont)], 'fontsize',12,'interpreter','latex');

    case 'Total K' %

        h2=plot(handles.t,handles.kiont);grid on;zoom on
        ylabel('$\sum K^{+}~ [\mu A/\mu F]$','FontSize',12,'FontWeight','bold','interpreter','latex') ;
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
      % title(['$\int\sum K^{+}dt=$', num2str(handles.Int_kiont)], 'fontsize',12,'interpreter','latex');
        
       case 'SR flux' %

        h2=plot(handles.t,handles.SR_flux);grid on;zoom on
        ylabel('$\sum Ca^{2+}_{SR}~ [mM]$','FontSize',12,'FontWeight','bold','interpreter','latex') ;
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
        title(['$\int\sum Ca^{2+}_{SR}dt=$', num2str(handles.SR_flux_avg)], 'fontsize',12,'interpreter','latex');  

case 'dVdT' %

        h2=plot(handles.t,handles.I_Total);grid on;zoom on
        ylabel('$\frac{\partial{V}}{\partial{t}}$ [mV]','FontSize',14,'FontWeight','bold','interpreter','latex') ;
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
 case 'CaMKII' %

        h2=plot(handles.t,handles.CamKII_active);grid on;zoom on
        ylabel('CaMKII $\%$ ','FontSize',14,'FontWeight','bold','interpreter','latex') ;
        set(h2,'LineWidth',2');set(gca,'FontSize',10,'FontWeight','bold')
            
       
end





% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

%handles.axes1=handles.axes2;guidata(hObject, handles);

v=get(hObject,'Value');
if v==1
    axes(handles.axes1);
    handles.v=v;

else
    axes(handles.axes2)
    handles.v=v;

end
guidata(hObject, handles);



% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);








% 


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2




% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2




% --- Executes on button press in checkMiddle.
function checkMiddle_Callback(hObject, eventdata, handles)
% hObject    handle to checkMiddle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkMiddle
    axes(handles.axes2)
    handles.v=1;


guidata(hObject, handles);

% --- Executes on button press in Bottom.
function Bottom_Callback(hObject, eventdata, handles)
% hObject    handle to Bottom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Bottom
    axes(handles.axes3)
    handles.v=0;


guidata(hObject, handles);

% --------------------------------------------------------------------
function uipanel1_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = get(hObject,'SelectedObject')
switch get(selection,'Tag')
case 'Bottom'
'bottom'
case 'checkMiddle'
% code piece when radiobutton2 is selected goes here
'middle'
end



% --- Executes on button press in pushbuttonClose.
function pushbuttonClose_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonClose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get the current position of the GUI from the handles
% to pass to the modal dialog.
pos_size = get(handles.figure1,'Position');
% Call modaldlg with the argument 'Position'.
user_response = modaldlg('Title','Confirm Close');
switch user_response
case {'No'}
% take no action
case 'Yes'
% Prepare to close GUI application window
% .
% .
% .
delete(handles.figure1)
end

% --- Executes on button press in pushbuttonSave.
function pushbuttonSave_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

t=handles.Time*1000;%% conversion second to milliseconds
currents=handles.currents;
States=handles.State;
%save  DATA.mat  t States currents 
% Get the Tag of the menu selected
Tag = get(hObject, 'Tag');
% Get the address array
% Addresses = handles.Addresses;
% Based on the item selected, take the appropriate action
switch Tag
case 'Save'
% Save to the default addrbook file
%File = handles.LastFile;
%save(File,'Addresses')
%save  DATA.mat  t States currents 
case 'pushbuttonSave'
% Allow the user to select the file name to save to
[filename, pathname] = uiputfile( ...
{'*.mat';'*.*'}, ...
'Save as');
% If 'Cancel' was selected then return
if isequal([filename,pathname],[0,0])
return
else
% Construct the full path and save
File = fullfile(pathname,filename);
save(File,'t','States','currents','-v6') 
% save(File,'Data')
% save(File,currents)
%handles.LastFile = File;
guidata(hObject, handles)
end
end


% --- Executes on button press in pushbuttonHelp.
function pushbuttonHelp_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



HelpPath = which('HELP_LRd2007.html');
web(HelpPath);



function editLastBCL_Callback(hObject, eventdata, handles)
% hObject    handle to editLastBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editLastBCL as text
%        str2double(get(hObject,'String')) returns contents of editLastBCL as a double
LastBCL = str2double(get(handles.editLastBCL,'String'));
handles.LastBCL =LastBCL;

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function editLastBCL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editLastBCL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on button press in pushLoad.
function pushLoad_Callback(hObject, eventdata, handles)
% hObject    handle to pushLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[file,path]=uigetfile('*.mat','Select the MAT-file');
%data = load(fullfile(file));
if file~=0
load(file);

Import(States,currents,t,handles);

end


function b=Import(State,currents,t,handles)

b=1;
t=t/1000;%% Conversion msec to second
handles.t=t;
handles.State=State;
handles.currents=currents;
handles.Time=t;
handles.V=State(:,1);
handles.H=State(:,2);
handles.M=State(:,3);
handles.J=State(:,4);
handles.d=State(:,5);
handles.f=State(:,6);
handles.Xr=State(:,7);
handles.Ca=currents.Cafree;
handles.Nai=State(:,9);
handles.Kai=State(:,10);
handles.JSR=currents.JSRfree;
handles.NSR=State(:,12);
handles.XS=State(:,13);
handles.Bc=State(:,14);
handles.Gc=State(:,15);
handles.XS2=State(:,16);

handles.INa=currents.INa;

%handles.icatot=currents.catot;
handles.ical=currents.ical;
handles.icalna=currents.icalna;
handles.icat=currents.icat;
handles.icalk=currents.icalk;
handles.itr=currents.itr;
handles.ikr=currents.ikr;
handles.iup=currents.iup;
handles.inak=currents.inak;
handles.stm=currents.stm;
handles.ir=State(:,17);
handles.IKp=currents.IKp;
handles.caiont=currents.caiont;
handles.inaca=currents.inaca;
handles.ileak=currents.ileak;
handles.ipca=currents.ipca;
handles.cmdn=currents.cmdn;
handles.trpn=currents.trpn;
handles.csqn=currents.csqn;
handles.iks=currents.iks;
handles.inab=currents.inab;
handles.icab=currents.icab;
handles.IK1=currents.IK1;

handles.G_Ks=currents.G_Ks;
handles.G_Kr=currents.G_Kr;
handles.G_K1=currents.G_K1;
handles.fca=currents.fca;

handles.caiont=currents.caiont;
handles.kiont=currents.kiont;
handles.naiont=currents.naiont;

% handles.Int_caiont=currents.Int_caiont;
% handles.Int_naiont=currents.Int_naiont;
% handles.Int_kiont=currents.Int_kiont;
 handles.I_Total=currents.naiont+currents.kiont+currents.caiont;
% 
% handles.SR_flux_avg=currents.SR_flux_avg;
% handles.SR_flux=currents.SR_flux;







axes(handles.axes1)
    h=plot(t,State(:,1));set(h,'LineWidth',2')
set(handles.axes1,'XMinorTick','on')
grid on; zoom on

ylabel('V (mV)','FontSize',10,'FontWeight','bold','FontWeight','bold');
set(gca,'FontWeight','bold','FontSize',10,'FontWeight','bold')
xlabel('Time (sec)','FontSize',10,'FontWeight','bold')


axes(handles.axes2)
h2=plot(t,1000*handles.Ca);
zoom on;   set(h2,'LineWidth',2')
set(handles.axes2,'XMinorTick','on')
grid on ; ylabel(' Ca^{2+} (\mu M)','FontSize',10,'FontWeight','bold')
set(gca,'FontSize',10,'FontWeight','bold')
xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
set(gca,'FontSize',10,'FontWeight','bold')
axes(handles.axes3)
h2=plot(t,handles.stm);
zoom on;   set(h2,'LineWidth',2')
set(handles.axes2,'XMinorTick','on')
grid on ; ylabel(' Stimuli (\mu A/\mu  F) ','FontSize',10,'FontWeight','bold')
set(gca,'FontSize',10,'FontWeight','bold')
xlabel('Time (sec)','FontSize',10,'FontWeight','bold')
%guidata(hObject, handles)
linkaxes([handles.axes1 handles.axes2 handles.axes3],'x');
guidata(handles.output,handles);


% --- Executes on slider movement.
function sliderCalcium_Callback(hObject, eventdata, handles)
% hObject    handle to sliderCalcium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
ca_o=get(handles.sliderCalcium, 'value');;
set(handles.editCalcium,'String',num2str(ca_o));


handles.ca_o=ca_o;


% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function sliderCalcium_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sliderCalcium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function editCalcium_Callback(hObject, eventdata, handles)
% hObject    handle to editCalcium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editCalcium as text
%        str2double(get(hObject,'String')) returns contents of editCalcium as a double

ca_o = str2double(get(handles.editCalcium,'String'));

if  ca_o >= get(handles.sliderCalcium,'Min') & ...
        ca_o <= get(handles.sliderCalcium,'Max')
    set(handles.sliderCalcium,'Value', ca_o);
elseif ca_o >get(handles.sliderCalcium,'Max')
    set(handles.sliderCalcium,'Value',get(handles.sliderCalcium,'Max'));
    set(handles.editCalcium,'String',num2str(get(handles.sliderCalcium,'Max')))
elseif ca_o < get(handles.sliderCalcium,'Min')

    set(handles.sliderCalcium,'Value',get(handles.sliderCalcium,'Min'));
    set(handles.editCalcium,'String',num2str(get(handles.sliderCalcium,'Min')))

else

    set(handles.sliderCalcium,'Value',get(handles.sliderCalcium,'Min'));
    set(handles.editCalcium,'String',num2str(get(handles.sliderCalcium,'Min')))
end

handles.ca_o =ca_o ;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editCalcium_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editCalcium (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton4.
function togglebutton4_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton4
printdlg('-crossplatform')
%
% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

printdlg


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

printpreview
